rsproject Folder is to be Saved in

\xampp\mysql\data